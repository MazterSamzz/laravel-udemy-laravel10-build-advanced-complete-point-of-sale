
<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Add Blog Category</h4>

                            <form id="myForm" method="post" action="<?php echo e(route('blog-categories.store')); ?>">
                                <?php echo csrf_field(); ?>

                                
                                <div class="row mb-3">
                                    <label  for="name" class="col-sm-2 col-form-label">Blog Category Name</label> 
                                    <div class="form-group col-sm-10">
                                        <input id="name" name="name" class="form-control" type="text" placeholder="Blog Category Name" value="<?php echo e(old('name')); ?>" autofocus />
                                        
                                    </div>
                                </div> <!-- end row -->
                                <input type="submit" value="Insert Blog Category" class="btn btn-info btn-round">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#myForm').validate({
                rules: {
                    name: {
                        required : true,
                    },
                },
                messages: {
                    name: {
                        required : 'Please Enter Blog Category',
                    },
                },
                errorElement : 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight : function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight : function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/admin/blog_categories/create.blade.php ENDPATH**/ ?>