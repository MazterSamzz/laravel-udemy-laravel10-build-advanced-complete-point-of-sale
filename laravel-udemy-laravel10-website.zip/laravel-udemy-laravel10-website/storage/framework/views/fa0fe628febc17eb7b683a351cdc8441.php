<form action="<?php echo e($action); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <button id="delete" class="btn btn-danger sm" title="Delete Data" type="submit" disabled><i class="fas fa-trash-alt"></i></button>
</form><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/admin/parts/form-delete-button.blade.php ENDPATH**/ ?>