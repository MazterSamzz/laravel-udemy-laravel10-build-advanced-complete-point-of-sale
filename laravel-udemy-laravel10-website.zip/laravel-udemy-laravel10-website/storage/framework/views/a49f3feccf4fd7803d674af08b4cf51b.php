
<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Blog Category Edit Page</h4>

                            <form method="post" action="<?php echo e(route('blog-categories.update', ['blog_category' => $blog_category->slug])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                
                                <div class="row mb-3">
                                    <label  for="name" class="col-sm-2 col-form-label">Blog Category Name</label>
                                    <div class="col-sm-10">
                                        <input id="name" name="name" class="form-control" type="text" placeholder="Blog Category Name" value="<?php echo e($blog_category->name); ?>" />
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div> <!-- end row -->
                                <input type="submit" value="Update Portfolio Data" class="btn btn-info btn-round">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/admin/blog_categories/edit.blade.php ENDPATH**/ ?>