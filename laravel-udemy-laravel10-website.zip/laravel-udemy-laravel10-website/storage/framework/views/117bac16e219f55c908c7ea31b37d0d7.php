
<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Footer Page</h4>

                            <form method="post" action="<?php echo e(route('footer.update')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>

                                <input type="hidden" name="id" value="<?php echo e($footer->id); ?>">

                                <!-- Input number -->
                                <div class="row mb-3">
                                    <label  for="number" class="col-sm-2 col-form-label">Number</label> 
                                    <div class="col-sm-10">
                                        <input id="number" name="number" class="form-control" type="text" placeholder="Number" value="<?php echo e(old('number') ? old('number') : $footer->number); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Input number -->
                                
                                <!-- // Short description -->
                                <div class="row mb-3">
                                    <label for="short_description" class="col-sm-2 col-form-label">Short Description</label>
                                    <div class="col-sm-10">
                                        <textarea id="short_description" name="short_description" class="form-control" required="" rows="5"><?php echo e(old('short_description') ? old('short_description') : $footer->short_description); ?></textarea>
                                    </div>
                                    <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Short description -->
                                
                                <!-- // Input address -->
                                <div class="row mb-3">
                                    <label  for="address" class="col-sm-2 col-form-label">Address</label> 
                                    <div class="col-sm-10">
                                        <input id="address" name="address" class="form-control" type="text" placeholder="Address" value="<?php echo e(old('address') ? old('address') : $footer->address); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Input address -->
                                
                                <!-- // Input email -->
                                <div class="row mb-3">
                                    <label  for="email" class="col-sm-2 col-form-label">Email</label> 
                                    <div class="col-sm-10">
                                        <input id="email" name="email" class="form-control" type="text" placeholder="Email" value="<?php echo e(old('email') ? old('email') : $footer->email); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Input email -->
                                
                                <!-- // Input facebook -->
                                <div class="row mb-3">
                                    <label  for="facebook" class="col-sm-2 col-form-label">Facebook</label> 
                                    <div class="col-sm-10">
                                        <input id="facebook" name="facebook" class="form-control" type="text" placeholder="Facebook" value="<?php echo e(old('facebook') ? old('facebook') : $footer->facebook); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Input facebook -->
                                
                                <!-- // Input twitter -->
                                <div class="row mb-3">
                                    <label  for="twitter" class="col-sm-2 col-form-label">Twitter</label> 
                                    <div class="col-sm-10">
                                        <input id="twitter" name="twitter" class="form-control" type="text" placeholder="Twitter" value="<?php echo e(old('twitter') ? old('twitter') : $footer->twitter); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Input twitter -->
                                
                                <!-- // Input Copyright -->
                                <div class="row mb-3">
                                    <label  for="copyright" class="col-sm-2 col-form-label">Copyright</label> 
                                    <div class="col-sm-10">
                                        <input id="copyright" name="copyright" class="form-control" type="text" placeholder="Copyright" value="<?php echo e(old('copyright') ? old('copyright') : $footer->copyright); ?>" />
                                    </div>
                                    <?php $__errorArgs = ['copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> <!-- end of Input address -->
                                
                                
                                <input type="submit" value="Update About Page" class="btn btn-info btn-round">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#image').change(function (e){
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/admin/footer/edit.blade.php ENDPATH**/ ?>