<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>About Page</title>
</head>
<body>
  <h1>This is About Page from Controller</h1>
  <a href="<?php echo e(route('contact.page')); ?>">Contact</a>
</body>
</html><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-build-advanced-complete-point-of-sale\resources\views/about.blade.php ENDPATH**/ ?>