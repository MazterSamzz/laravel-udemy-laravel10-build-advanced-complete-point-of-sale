

<?php $__env->startSection('title'); ?>
    Home | Ivan - Personal Portfolio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    

    <!-- banner-area -->
    <?php echo $__env->make('frontend.home_all.home_slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- about-area -->
    <?php echo $__env->make('frontend.home_all.home_about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- portfolio-area -->
    <?php echo $__env->make('frontend.home_all.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- blog-area -->
    <?php echo $__env->make('frontend.home_all.home_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- blog-area-end -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/frontend/index.blade.php ENDPATH**/ ?>