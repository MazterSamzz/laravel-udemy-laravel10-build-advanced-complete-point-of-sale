<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Contact Page</title>
</head>
<body>
  <h2>This is a Contact Page from Controller</h2>
  <a href="<?php echo e(route('about.page')); ?>">About</a>
</body>
</html><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-build-advanced-complete-point-of-sale\resources\views/contact.blade.php ENDPATH**/ ?>