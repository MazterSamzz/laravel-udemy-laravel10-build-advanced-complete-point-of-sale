<?php
    $blogs = App\Models\Blog::latest()->limit(3)->get();
?>

<section class="blog">
    <div class="container">
        <div class="row gx-0 justify-content-center">

            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-9">
                    <div class="blog__post__item">
                        <div class="blog__post__thumb">
                            <a href="blog-details.html"><img src="<?php echo e($blog->image); ?>" alt=""></a>
                            <div class="blog__post__tags">
                                <a href="blog.html"><?php echo e($blog->category->name); ?></a>
                            </div>
                        </div>
                        <div class="blog__post__content">
                            <span class="date"><?php echo e(Carbon\Carbon::parse($blog->created_at)->diffForHumans()); ?></span>
                            <h3 class="title"><a href="<?php echo e(route('blogs.show', ['blog' => $blog->slug])); ?>"><?php echo e($blog->title); ?></a></h3>
                            <a href="<?php echo e(route('blogs.show', ['blog' => $blog->slug])); ?>" class="read__more">Read mORe</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <div class="blog__button text-center">
            <a href="blog.html" class="btn">more blog</a>
        </div>
    </div>
</section><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/frontend/home_all/home_blog.blade.php ENDPATH**/ ?>