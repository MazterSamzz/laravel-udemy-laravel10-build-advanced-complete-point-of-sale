<?php
    foreach ($categories as $category) {
        $count = App\Models\Blog::where('blog_category_id', $category->id)->count();
        $counts[$category->id] = $count;
    }
?>

<div class="col-lg-4">
    <aside class="blog__sidebar">
        <div class="widget">
            <form action="#" class="search-form">
                <input type="text" placeholder="Search">
                <button type="submit"><i class="fal fa-search"></i></button>
            </form>
        </div>
        <div class="widget">
            <h4 class="widget-title">Recent Blog</h4>
            <ul class="rc__post">

                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="rc__post__item">
                        <div class="rc__post__thumb">
                            <a href="<?php echo e(route('blogs.show', ['blog' => $item->slug])); ?>"><img src="<?php echo e(asset($item->image)); ?>" alt=""></a>
                        </div>
                        <div class="rc__post__content">
                            <h5 class="title"><a href="<?php echo e(route('blogs.show', ['blog' => $item->slug])); ?>"><?php echo e($item->title); ?></a></h5>
                            <span class="post-date"><i class="fal fa-calendar-alt"></i> <?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></span>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

            </ul>
        </div>
        <div class="widget">
            <h4 class="widget-title">Categories</h4>
            <ul class="sidebar__cat">

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $count = App\Models\Blog::where('blog_category_id', $category->id)->count();
                ?>
                    <li class="sidebar__cat__item"><a href="<?php echo e(route('blog-categories.show', ['blog_category' => $category->slug])); ?>"><?php echo e($category->name); ?> (<?php echo e($count); ?>)</a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
        </div>
        <div class="widget">
            <h4 class="widget-title">Recent Comment</h4>
            <ul class="sidebar__comment">
                <li class="sidebar__comment__item">
                    <a href="blog-details.html">Rasalina Sponde</a>
                    <p>There are many variations of passages of lorem ipsum available, but the majority have</p>
                </li>
                <li class="sidebar__comment__item">
                    <a href="blog-details.html">Rasalina Sponde</a>
                    <p>There are many variations of passages of lorem ipsum available, but the majority have</p>
                </li>
                <li class="sidebar__comment__item">
                    <a href="blog-details.html">Rasalina Sponde</a>
                    <p>There are many variations of passages of lorem ipsum available, but the majority have</p>
                </li>
                <li class="sidebar__comment__item">
                    <a href="blog-details.html">Rasalina Sponde</a>
                    <p>There are many variations of passages of lorem ipsum available, but the majority have</p>
                </li>
            </ul>
        </div>
        <div class="widget">
            <h4 class="widget-title">Popular Tags</h4>
            <ul class="sidebar__tags">
                <li><a href="blog.html">Business</a></li>
                <li><a href="blog.html">Design</a></li>
                <li><a href="blog.html">apps</a></li>
                <li><a href="blog.html">landing page</a></li>
                <li><a href="blog.html">data</a></li>
                <li><a href="blog.html">website</a></li>
                <li><a href="blog.html">book</a></li>
                <li><a href="blog.html">Design</a></li>
                <li><a href="blog.html">product design</a></li>
                <li><a href="blog.html">landing page</a></li>
                <li><a href="blog.html">data</a></li>
            </ul>
        </div>
    </aside>
</div><?php /**PATH D:\Samzz\Programming\htdocs\laravel-udemy-laravel10-point-of-sales\laravel-udemy-laravel10-website\resources\views/frontend/blog/right_sidebar.blade.php ENDPATH**/ ?>