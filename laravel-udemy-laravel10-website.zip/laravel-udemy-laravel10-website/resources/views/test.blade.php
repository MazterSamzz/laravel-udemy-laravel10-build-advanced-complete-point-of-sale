

<?php
  $world = "Hi Ariyan";
  echo $world;
?>

{{ $world }}

if($world) {

}else{

}

@if()

@endif

@foreach

@endforeach